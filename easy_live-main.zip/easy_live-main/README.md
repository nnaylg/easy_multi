# easy_live
Grâce à ce répertoire vous pouvez installer très simplement et gratuitement votre premier bot de trading sur un serveur pour qu'il puisse tourner 24h/24 et 7j/7.

Nous utiliserons ici les serveur du géant du cloud AWS qui propose des serveurs gratuits pendant 1 an. Donc le prérequis est de créer un compte AWS.   
Pour faire nos échanges cryptos nous utiliserons FTX qui est une des plateformes les plus compétitves en terme de frais et surtout FTX permet d'avoir accès à des sous comptes ce qui est indispensable pour faire des bots de trading. Si vous n'avez pas encore de compte n'oubliez pas de vous en créer un grâce à un lien d'affiliation afin de réduire vos frais (indispensable pour les bots de trading), voici le notre si vous souhaitez nous soutenir https://ftx.com/#a=cryptorobot

Une fois connecté à votre serveur il suffit de faire 2 commandes:

> git clone https://github.com/CryptoRobotFr/easy_live.git (attention ne pas copier coller toute la commande)

renommer le repertoire easy_live si vous souhaitez avoir plusieurs bots 
> cd <votre repertoire>
> bash install.sh

Ensuite il suffit de suivre les instructions en rentrant vos clé api FTX, le nom de votre sous compte, et enfin le nom de la stratégie souhaité parmis la liste ci dessous. Une fois que tout est fait si vous n'avez pas de message d'erreur c'est que tout est bon.

vous pouvez avoir les infos de la derniere execution du bot dans le fichier cronlog.log

## Liste des stratégies disponibles:
- cross_ema_secure
- alligator
